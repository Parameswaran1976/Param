package com.htc.main;

import java.sql.SQLException;

import com.htc.DAO.BankProviderImpl;
import com.htc.DTO.BankAccount;

public class MainClass {

	public static void main(String[] args) throws SQLException {
		BankProviderImpl impl = new BankProviderImpl();
//		System.out.println(impl.insertaccount(new BankAccount("Sarath")));

	}

}
