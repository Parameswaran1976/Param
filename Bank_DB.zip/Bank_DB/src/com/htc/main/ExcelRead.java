package com.htc.main;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.htc.DAO.BankSPImpl;
import com.htc.DTO.BankAccount;

public class ExcelRead {
	public static final String FILE_PATH = "./bank_account_details.xls";
	//private ArrayList<ExcelRead> arrayOfexcelvalues = new ArrayList<>();

	public static void main(String[] args) throws InvalidFormatException, IOException, SQLException {

		Workbook workbook = WorkbookFactory.create(new File(FILE_PATH));
//		System.out.println(workbook.getNumberOfSheets());

		/*
		 * for(Sheet sheet:workbook){ System.out.println(sheet.getSheetName()); }
		 */

		Sheet sheet = workbook.getSheetAt(0);
//		DataFormatter dataFormatter = new DataFormatter();

		for (Row row : sheet) {
			/*
			 * for(Cell cell:row){ // String cellValue =
			 * dataFormatter.formatCellValue(cell); printCellValue(cell); //
			 * System.out.println(cell +"\t" );
			 * 
			 * }
			 */

//			System.out.println(row.getCell(0));
			int accno = (int) row.getCell(0).getNumericCellValue();
			String accname = row.getCell(1).getStringCellValue();
			double bal = row.getCell(2).getNumericCellValue();

			BankAccount bacc = new BankAccount(accno, accname, bal);
			/*
			 * BankSPImpl spimpl = new BankSPImpl(); spimpl.insertaccount(bacc);
			 * System.out.println(bacc);
			 */
		}
	}

	/*
	 * private static void printCellValue(Cell cell) { Object o =null;
	 * 
	 * System.out.print(cell.getCellTypeEnum()); switch (cell.getCellTypeEnum()) {
	 * 
	 * case BOOLEAN: boolean booleanvalue=cell.getBooleanCellValue(); //
	 * System.out.println("Value is " + studentid);
	 * System.out.print(cell.getBooleanCellValue()); // return booleanvalue; break;
	 * case STRING: String studentid=cell.getStringCellValue(); //
	 * System.out.println("Value is " + studentid1 + " cell value is " +
	 * cell.getCellTypeEnum());
	 * System.out.print(cell.getRichStringCellValue().getString()); break; case
	 * NUMERIC: System.out.println("Cell style" + cell.getCellStyle()); float value
	 * = (float) cell.getNumericCellValue();
	 * System.out.print(cell.getNumericCellValue()); if
	 * (DateUtil.isCellDateFormatted(cell)) {
	 * System.out.print(cell.getDateCellValue()); } else {
	 * System.out.print(cell.getNumericCellValue()); } break; case FORMULA:
	 * System.out.print(cell.getCellFormula()); break; case BLANK:
	 * System.out.print(""); break; default: System.out.print(""); }
	 * System.out.print("\t"); }
	 */
}
