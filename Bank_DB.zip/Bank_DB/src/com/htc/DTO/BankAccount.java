package com.htc.DTO;

import java.util.Arrays;

public class BankAccount {	
	private int accountNo;
	private String accountName;
	private double balance = 1000;
	
	public BankAccount(int accountNo, String accountName, double balance) {
		super();
		this.accountNo = accountNo;
		this.accountName = accountName;
		this.balance = balance;
		System.out.println("accountNo=" + this.accountNo + ", accountName=" + this.accountName + ", balance=" + this.balance);
		
	}
//	private double balance = 1000;
//	private static int lastAssignedNo = 0;
	public BankAccount() {
		super();
		// TODO Auto-generated constructor stub
	}
	/*public BankAccount(String accountName) {
		super();
		lastAssignedNo += 1;
		
		this.accountNo = lastAssignedNo;
		//System.out.println(this.accountNo);
		this.accountName = accountName;
	}*/
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", accountName=" + accountName + ", balance=" + balance + "]";
	}
	
	
	

}
