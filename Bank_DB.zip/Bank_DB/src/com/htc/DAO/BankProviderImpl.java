package com.htc.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.htc.DTO.BankAccount;
import com.htc.jdbcapp.connector.DBConnector;

public class BankProviderImpl implements IBankProvider{

	@Override
	public boolean insertaccount(BankAccount ba) throws SQLException {
		boolean insertFlag = false;
		Connection con = DBConnector.getConnection();
		PreparedStatement ps = con.prepareStatement("INSERT INTO bankaccount(accountno,accountname,balance) VALUES(?,?,?)");
		ps.setInt(1, ba.getAccountNo());
		ps.setString(2, ba.getAccountName());
		ps.setDouble(3, ba.getBalance());
		
		insertFlag = !ps.execute();
		
		return insertFlag;
	}

	@Override
	public boolean deleteaccount(long accountNumber) throws SQLException {
		boolean deleteFlag = false;
		Connection con = DBConnector.getConnection();
		PreparedStatement ps = con.prepareStatement("DELETE FROM bankaccount WHERE accountno=?");
		
		
		return deleteFlag;
	}

	@Override
	public boolean updateaccount(long accountNumber, BankAccount ba1) throws SQLException {
		boolean updateFlag = false;
		Connection con = DBConnector.getConnection();
		PreparedStatement ps = con.prepareStatement("UPDATE bankaccount SET balance=? where accountno = ?");
		
		return false;
	}

	@Override
	public ArrayList<BankAccount> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

}
