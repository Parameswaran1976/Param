package com.htc.DAO;

import java.sql.SQLException;
import java.util.ArrayList;

import com.htc.DTO.BankAccount;

public interface IBankProvider {
	public boolean insertaccount(BankAccount ba) throws SQLException;
	public boolean deleteaccount(long accountNumber) throws SQLException;
	public boolean updateaccount(long accountNumber, BankAccount ba1) throws SQLException;
	public ArrayList<BankAccount> getAllAccounts() throws SQLException;
}
