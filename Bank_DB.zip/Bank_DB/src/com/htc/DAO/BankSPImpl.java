package com.htc.DAO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import com.htc.DTO.BankAccount;
import com.htc.jdbcapp.connector.DBConnector;
public class BankSPImpl implements IBankProvider {

	
	@Override
	public boolean insertaccount(BankAccount ba) throws SQLException {
		Connection con = DBConnector.getConnection();
		CallableStatement cstmt = con.prepareCall("{?=call insertaccount(?,?,?)}");
		cstmt.registerOutParameter(1, java.sql.Types.BOOLEAN);
		cstmt.setInt(2, ba.getAccountNo());
		cstmt.setString(3, ba.getAccountName());
		cstmt.setDouble(4, ba.getBalance());		
		cstmt.execute();
		if (cstmt.getBoolean(1)) {
			System.out.println("True");
			return true;
		} else
			return false;
	}

	@Override
	public boolean deleteaccount(long accountNumber) throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateaccount(long accountNumber, BankAccount ba1)
			throws SQLException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<BankAccount> getAllAccounts() throws SQLException {
		Connection con = DBConnector.getConnection();
		CallableStatement cstmt = con.prepareCall("{?=call get_accounts()}");
		
	
		return null;
		
	}

}
