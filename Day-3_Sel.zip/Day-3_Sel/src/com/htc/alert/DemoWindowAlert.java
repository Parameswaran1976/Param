package com.htc.alert;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.htc.webdrivergenerator.DriverGenerator;

public class DemoWindowAlert {
WebDriver driver;
@BeforeMethod
public void setUp() throws InterruptedException
{
driver=DriverGenerator.genDriver();
TimeUnit.SECONDS.sleep(2);
driver.get("https://gmail.com");
driver.manage().window().maximize();
}


@Test
public void testWindowAlert() throws Exception{

//enter a valid email address
WebElement email=driver.findElement(By.xpath("//*[@id=\'identifierId\']"));
email.sendKeys("seltestng8807@gmail.com" );
//email.submit();
WebElement next=(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("identifierNext")));

next.click();

//enter a valid password
//*[@id="password"]/div[1]/div/div[1]/input
WebElement password=(new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.name("password")));
		/*
		 * Actions action0 = new Actions(driver);
		 * action0.moveToElement(password).click().build().perform();
		 */

((JavascriptExecutor)driver).executeScript("arguments[0].click();", password);
password.sendKeys("123Welcome");
WebElement nextPassword=(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.id("passwordNext")));

//*[@id=":3q"]/div/div

//click on sign in button
//nextPassword.click();
Actions action1 = new Actions(driver);
action1.moveToElement(nextPassword).click().build().perform();
System.out.println("clicked on next");

Thread.sleep(10000);
//driver.manage().timeouts().pageLoadTimeout(10,TimeUnit.SECONDS);


//WebElement compose=(new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='nH']//div[@class=nH bkL]//div[@class='z0']//div[@class='T-I J-J5-Ji T-I-KE L3']")));
//WebElement compose=(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='z0']//div[contains(text(),'Compose')]")));
//WebElement compose=(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[text()='Compose')]")));
driver.findElement(By.xpath("//div[text()='Compose']")).click();
//WebElement compose=(new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.partialLinkText("Compose")));
//System.out.println("compose"+compose);
////div[contains(text(),'Compose')]
//click on compose button
//compose.click();
		/*
		 * Actions action3 = new Actions(driver);
		 * action1.moveToElement(compose).click().build().perform();
		 */

//click on attach files icon
WebElement attach=(new WebDriverWait(driver, 10)).until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[contains(@command,'Files')]//div[contains(@class,'aaA')]")));
attach.click();

//creating instance of Robot class (A java based utility)
Robot rb =new Robot();
Thread.sleep(3000);
//pressing keys with the help of keyPress and keyRelease events
rb.keyPress(KeyEvent.VK_C);
rb.keyRelease(KeyEvent.VK_C);
Thread.sleep(2000);

rb.keyPress(KeyEvent.VK_SHIFT);
rb.keyPress(KeyEvent.VK_SEMICOLON);
rb.keyRelease(KeyEvent.VK_SEMICOLON);
rb.keyRelease(KeyEvent.VK_SHIFT);

rb.keyPress(KeyEvent.VK_BACK_SLASH);
rb.keyRelease(KeyEvent.VK_BACK_SLASH);
Thread.sleep(2000);

rb.keyPress(KeyEvent.VK_P);
rb.keyRelease(KeyEvent.VK_P);

rb.keyPress(KeyEvent.VK_I);
rb.keyRelease(KeyEvent.VK_I);

rb.keyPress(KeyEvent.VK_C);
rb.keyRelease(KeyEvent.VK_C);
Thread.sleep(2000);

rb.keyPress(KeyEvent.VK_BACK_SLASH);
rb.keyRelease(KeyEvent.VK_BACK_SLASH);
Thread.sleep(2000);

rb.keyPress(KeyEvent.VK_A);
rb.keyRelease(KeyEvent.VK_A);
Thread.sleep(2000);


rb.keyPress(KeyEvent.VK_ENTER);
rb.keyRelease(KeyEvent.VK_ENTER);
Thread.sleep(2000);
}

@AfterMethod
public void tearDown()
{
//driver.quit();
}
} 