package com.htc.objectrepo;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.htc.webdrivergenerator.DriverGenerator;
//jaxen.jar
//dom4j-1.6.jar IN XMLPARSING FOLDER

public class ObjectRepoXML{
    @Test
	public static void xmltest() throws DocumentException, InterruptedException  {
		// Creating WebDriver Instance
		WebDriver driver=DriverGenerator.genDriver();
		
		
		driver.get("http://demo.guru99.com/test/guru99home/");
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		// Reading XML File
		File inputFile = new File(System.getProperty("user.dir") + "\\repo.xml");
		SAXReader saxReader = new SAXReader();
		Document document = saxReader.read(inputFile);
		String mobileTesting = document.selectSingleNode("//menu/mobiletesting").getText();
		String emailTextBox = document.selectSingleNode("//menu/emailxpath").getText();
		String signUpButton = document.selectSingleNode("//menu/signupxpath").getText();

		// Navigating to Mobile Testing and back
		WebElement testinglink;
		testinglink=new WebDriverWait(driver, 15).until(ExpectedConditions.presenceOfElementLocated(By.xpath(mobileTesting)));
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
         System.out.println(testinglink);
		//testinglink.click();
		//driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);

		
		//driver.navigate().back();
		driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS);
		// Entering Form Data
		WebElement emailBox=new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(emailTextBox)));
		emailBox.sendKeys("testguru99@gmail.com");
		WebElement signup=new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfElementLocated(By.xpath(signUpButton)));

        signup.click();
        // accepting javascript alert
       
         Alert alert = driver.switchTo().alert();
         Thread.sleep(3000);

        alert.accept();
        Thread.sleep(5000);
        driver.quit();
        
         


	}
}
