package com.htc.datatproviderexcel;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.htc.webdrivergenerator.DriverGenerator;



@Test
public class DataproviderEportalExcel {

	static WebDriver driver;

	@DataProvider(name = "validLoginData")
	public Object[][] setValidLoginData() throws IOException {

		Object[][] empdata = new Object[4][2];
		int rowIndex = 0;

		File xlsFile = new File("./Eportal_Login.xls");
		FileInputStream fin = null;
		HSSFWorkbook book = null;
		fin = new FileInputStream(xlsFile);

		book = new HSSFWorkbook(fin);
		Sheet sheet = book.getSheet("empdata");
		System.out.println("Workbook created");

		for (Row row : sheet) {

			// row.getCell(1).getStringCellValue();
			String empID = row.getCell(0).getStringCellValue();
			String password = row.getCell(1).getStringCellValue();
			empdata[rowIndex][0] = empID;
			empdata[rowIndex][1] = password;
			rowIndex++;
		}
		book.close();
		fin.close();
		return empdata;
	}

	@BeforeClass
	public void initializeDriver() {

		driver = DriverGenerator.genDriver();
		driver.navigate().to("https://eportal.htcindia.com/home/");
		WebElement employeeLoginBtn = (new WebDriverWait(driver, 2)).until(
				ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"header-right-section\"]/div/a")));

		employeeLoginBtn.click();

	}

	@AfterClass
	public static void closedriver() {
		driver.close();

	}

	@Test(dataProvider = "validLoginData")
	public void testSuccessLoginLogout(String username, String password) throws InterruptedException {
		
		WebElement unameElement = driver.findElement(By.name("user_name"));
		// System.out.println(unameElement.isEnabled());
		unameElement.sendKeys(username);
		WebElement passElement = driver.findElement(By.name("user_pass"));
		passElement.sendKeys(password);
		Thread.sleep(3000);
		WebElement subElement = driver
				.findElement(By.xpath("//*[@id=\"wrapper\"]/div/div[1]/div/div/div[2]/form/fieldset/button"));
		subElement.click();
		WebElement myDynamicElement = null;
		myDynamicElement = (new WebDriverWait(driver, 5))
				.until(ExpectedConditions.presenceOfElementLocated(By.className("logout_text")));

		if (myDynamicElement != null) {
			myDynamicElement.click();
			WebElement employeeLoginBtn = (new WebDriverWait(driver, 2)).until(
					ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"header-right-section\"]/div/a")));

			employeeLoginBtn.click();
		}
		Assert.assertNotNull(myDynamicElement);

	}

}
