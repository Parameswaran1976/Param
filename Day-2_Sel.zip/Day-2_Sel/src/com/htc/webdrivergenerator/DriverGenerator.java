package com.htc.webdrivergenerator;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverGenerator {
	public static WebDriver genDriver() {
		
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\htcuser\\Desktop\\Class files\\DRIVERS\\chromedriver.exe");
    	WebDriver driver = new ChromeDriver();
		return driver;
		
	}
	
public static WebDriver ffgenDriver() {
		
		
		System.setProperty("webdriver.gecko.driver","C:\\Users\\htcuser\\Desktop\\Class files\\DRIVERS\\\\geckodriver.exe");
    	WebDriver driver = new FirefoxDriver();
		return driver;
		
	}

public static WebDriver iegenDriver() {
	System.setProperty("webdriver.ie.driver","C:\\Users\\htcuser\\Desktop\\Class files\\DRIVERS\\\\IEDriverServer.exe");
	WebDriver driver = new InternetExplorerDriver();
	return driver;
	
}

public static WebDriver edgegenDriver() {
	System.setProperty("webdriver.edge.driver","C:\\Users\\htcuser\\Desktop\\Class files\\DRIVERS\\\\msedgedriver.exe");
	WebDriver driver = new EdgeDriver();
	return driver;
	
}


public static WebDriver headlessDriver() {
	return null;
	//WebDriver driver = new HtmlUnitDriver();
	
}

}
	
	
