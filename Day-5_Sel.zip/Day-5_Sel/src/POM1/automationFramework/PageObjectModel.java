package POM1.automationFramework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.htc.webdrivergenerator.DriverGenerator;

// Import package pageObject.*

import POM1.pageObjects.Home_Page;
import POM1.pageObjects.LogIn_Page;

public class PageObjectModel {

private static WebDriver driver = null;


public static void main(String[] args) {
driver = DriverGenerator.genDriver();
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
driver.get("https://ciberapps.in.ciber.com/CPulse/UserLogin/Start");
// Use page Object library now
Home_Page.lnk_MyAccount(driver).click();
LogIn_Page.txtbx_UserName(driver).sendKeys("pnagalingam");
LogIn_Page.txtbx_Password(driver).sendKeys("Siddarth13$$");
LogIn_Page.btn_LogIn(driver).click();
//Home_Page.lnk_LogOut(driver).click(); 
driver.quit();

}

}